Para correr el programa, primeramente debe instalarse "Flask". Para ello, desde el terminal debe ejecutarse el comando:

pip install flask

Posteriormente, se debe estar en la carpeta Vista y ejecutar el progrma server.py. En la linea de comando se ejecuta

python server.py

Al iniciar su navegador de preferencia, e ir a localhost:5000 se debería ejecutar el prototipo del programa.
 

